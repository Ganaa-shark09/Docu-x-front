import { DatePipe, NgFor, NgIf } from '@angular/common';
import { ChangeDetectorRef, Component, OnDestroy, inject } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Subscription, finalize, interval } from 'rxjs';

import { DocumentDetail, DocumentProcessingJob } from '../../../core/models/document.model';
import { DocumentStatusBadgeComponent } from '../components/document-status-badge.component';
import { DocumentsService } from '../services/documents.service';
import { DocumentProcessingPipelineComponent } from '../components/document-processing-pipeline.component';

@Component({
  selector: 'app-document-detail-page',
  standalone: true,
  imports: [
    DatePipe,
    DocumentStatusBadgeComponent,
    NgFor,
    NgIf,
    RouterLink,
    DocumentProcessingPipelineComponent,
  ],
  template: `
    <section class="w-full max-w-none space-y-6">
      <div class="flex flex-wrap items-start justify-between gap-4">
        <div>
          <a
            routerLink="/documents"
            class="mb-3 inline-block text-sm font-medium text-slate-500 hover:text-slate-900"
          >
            ← Back to documents
          </a>

          <h2 class="text-2xl font-bold text-slate-950">
            {{ document?.title || 'Document Detail' }}
          </h2>

          <p class="text-sm text-slate-500">
            {{ document?.original_filename }}
          </p>
        </div>

        <div class="flex gap-2">
          <button
            type="button"
            (click)="retryProcessing()"
            [disabled]="isRetrying || !document"
            class="rounded-xl bg-slate-950 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-400"
          >
            {{ isRetrying ? 'Retrying...' : 'Retry Processing' }}
          </button>

          <button
            type="button"
            (click)="deleteDocument()"
            [disabled]="isDeleting || !document"
            class="rounded-xl border border-red-300 px-4 py-2.5 text-sm font-semibold text-red-700 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {{ isDeleting ? 'Deleting...' : 'Delete' }}
          </button>
        </div>
      </div>

      <div
        *ngIf="errorMessage"
        class="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700"
      >
        {{ errorMessage }}
      </div>

      <div
        *ngIf="successMessage"
        class="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700"
      >
        {{ successMessage }}
      </div>

      <div
        *ngIf="isLoading"
        class="rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500 shadow-sm"
      >
        Loading document...
      </div>

      <ng-container *ngIf="document">
        <div class="grid gap-4 lg:grid-cols-4">
          <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <p class="text-sm font-medium text-slate-500">Status</p>
            <div class="mt-3">
              <app-document-status-badge [status]="document.status" />
            </div>
          </div>

          <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <p class="text-sm font-medium text-slate-500">AI Ready</p>
            <p class="mt-2 text-2xl font-bold text-slate-950">
              {{ document.is_ai_ready ? 'Yes' : 'No' }}
            </p>
          </div>

          <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <p class="text-sm font-medium text-slate-500">Indexed</p>
            <p class="mt-2 text-2xl font-bold text-slate-950">
              {{ document.is_indexed ? 'Yes' : 'No' }}
            </p>
          </div>

          <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <p class="text-sm font-medium text-slate-500">OCR Completed</p>
            <p class="mt-2 text-2xl font-bold text-slate-950">
              {{ document.is_ocr_completed ? 'Yes' : 'No' }}
            </p>
          </div>
        </div>
        <!-- <div class="rounded-2xl border border-slate-200 bg-white shadow-sm"> -->
        <div class="w-full max-w-none">
          <app-document-processing-pipeline
            [jobs]="processingJobs"
            (refresh)="loadProcessingJobs()"
          />
        </div>

        <div class="grid gap-6 xl:grid-cols-3">
          <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm xl:col-span-2">
            <h3 class="mb-4 font-semibold text-slate-950">Document Information</h3>

            <div class="grid gap-4 md:grid-cols-2">
              <div>
                <p class="text-xs font-semibold uppercase text-slate-400">Document Type</p>
                <p class="mt-1 text-sm text-slate-700">{{ formatLabel(document.document_type) }}</p>
              </div>

              <div>
                <p class="text-xs font-semibold uppercase text-slate-400">Sensitivity</p>
                <p class="mt-1 text-sm text-slate-700">
                  {{ formatLabel(document.sensitivity_label) }}
                </p>
              </div>

              <div>
                <p class="text-xs font-semibold uppercase text-slate-400">Department</p>
                <p class="mt-1 text-sm text-slate-700">{{ document.department_name || '-' }}</p>
              </div>

              <div>
                <p class="text-xs font-semibold uppercase text-slate-400">Uploaded By</p>
                <p class="mt-1 text-sm text-slate-700">{{ document.uploaded_by_email || '-' }}</p>
              </div>

              <div>
                <p class="text-xs font-semibold uppercase text-slate-400">File Size</p>
                <p class="mt-1 text-sm text-slate-700">{{ formatFileSize(document.file_size) }}</p>
              </div>

              <div>
                <p class="text-xs font-semibold uppercase text-slate-400">MIME Type</p>
                <p class="mt-1 text-sm text-slate-700">{{ document.mime_type || '-' }}</p>
              </div>

              <div>
                <p class="text-xs font-semibold uppercase text-slate-400">Created</p>
                <p class="mt-1 text-sm text-slate-700">
                  {{ document.created_at | date: 'medium' }}
                </p>
              </div>

              <div>
                <p class="text-xs font-semibold uppercase text-slate-400">Updated</p>
                <p class="mt-1 text-sm text-slate-700">
                  {{ document.updated_at | date: 'medium' }}
                </p>
              </div>
            </div>

            <div *ngIf="document.description" class="mt-5">
              <p class="text-xs font-semibold uppercase text-slate-400">Description</p>
              <p class="mt-1 text-sm text-slate-700">{{ document.description }}</p>
            </div>

            <div
              *ngIf="document.processing_error"
              class="mt-5 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700"
            >
              {{ document.processing_error }}
            </div>
          </div>

          <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 class="mb-4 font-semibold text-slate-950">Processing Flags</h3>

            <div class="space-y-3 text-sm">
              <div class="flex justify-between">
                <span class="text-slate-500">Current access</span>
                <span class="font-medium text-slate-900">{{
                  document.current_user_access || '-'
                }}</span>
              </div>

              <div class="flex justify-between">
                <span class="text-slate-500">Page count</span>
                <span class="font-medium text-slate-900">{{ document.page_count || '-' }}</span>
              </div>

              <div class="flex justify-between">
                <span class="text-slate-500">Language</span>
                <span class="font-medium text-slate-900">{{ document.language || '-' }}</span>
              </div>
            </div>
          </div>
        </div>

        <div class="rounded-2xl border border-slate-200 bg-white shadow-sm">
          <!-- <div class="w-full max-w-none">
            <app-document-processing-pipeline
              [jobs]="processingJobs"
              (refresh)="loadProcessingJobs()"
            />
          </div> -->

          <div *ngIf="!processingJobs.length" class="p-6 text-sm text-slate-500">
            No processing jobs found.
          </div>

          <div *ngIf="processingJobs.length" class="overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200">
              <thead class="bg-slate-50">
                <tr>
                  <th
                    class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500"
                  >
                    Job
                  </th>
                  <th
                    class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500"
                  >
                    Status
                  </th>
                  <th
                    class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500"
                  >
                    Started
                  </th>
                  <th
                    class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500"
                  >
                    Completed
                  </th>
                  <th
                    class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500"
                  >
                    Error
                  </th>
                </tr>
              </thead>

              <tbody class="divide-y divide-slate-100">
                <tr *ngFor="let job of processingJobs">
                  <td class="px-5 py-4 text-sm font-medium text-slate-900">
                    {{ formatLabel(job.job_type) }}
                  </td>

                  <td class="px-5 py-4 text-sm text-slate-600">
                    {{ formatLabel(job.status) }}
                  </td>

                  <td class="px-5 py-4 text-sm text-slate-500">
                    {{ job.started_at ? (job.started_at | date: 'medium') : '-' }}
                  </td>

                  <td class="px-5 py-4 text-sm text-slate-500">
                    {{ job.completed_at ? (job.completed_at | date: 'medium') : '-' }}
                  </td>

                  <td class="px-5 py-4 text-sm text-red-600">
                    {{ job.error_message || '-' }}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </ng-container>
    </section>
  `,
})
export class DocumentDetailPageComponent implements OnDestroy {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly documentsService = inject(DocumentsService);
  private readonly cdr = inject(ChangeDetectorRef);
  private pollingSubscription?: Subscription;

  document: DocumentDetail | null = null;
  processingJobs: DocumentProcessingJob[] = [];

  isLoading = false;
  isRetrying = false;
  isDeleting = false;
  errorMessage = '';
  successMessage = '';

  private readonly uuid = this.route.snapshot.paramMap.get('uuid') || '';

  constructor() {
    this.loadDocument();
    this.loadProcessingJobs();
  }
  ngOnDestroy(): void {
    this.stopProcessingPolling();
  }

  startProcessingPolling(): void {
    this.stopProcessingPolling();

    this.pollingSubscription = interval(5000).subscribe(() => {
      this.loadDocument(false);
      this.loadProcessingJobs(false);
    });
  }

  stopProcessingPolling(): void {
    this.pollingSubscription?.unsubscribe();
    this.pollingSubscription = undefined;
  }

  hasActiveProcessingJobs(): boolean {
    return this.processingJobs.some((job) => ['pending', 'running'].includes(job.status));
  }

  loadDocument(showLoader = true): void {
    if (showLoader) {
      this.isLoading = true;
    }

    this.errorMessage = '';

    this.documentsService.getDocument(this.uuid).subscribe({
      next: (document) => {
        console.log('Document detail loaded:', document);

        this.document = { ...document };
        this.isLoading = false;

        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Document detail API failed:', error);

        if (showLoader) {
          this.document = null;
        }

        this.isLoading = false;

        this.errorMessage =
          error?.error?.detail ||
          JSON.stringify(error?.error || {}) ||
          'Unable to load document detail.';

        this.cdr.detectChanges();
      },
    });
  }

  loadProcessingJobs(showLoader = true): void {
    this.documentsService.getProcessingJobs(this.uuid).subscribe({
      next: (jobs) => {
        console.log('Processing jobs loaded:', jobs);

        this.processingJobs = Array.isArray(jobs) ? [...jobs] : [];

        if (this.hasActiveProcessingJobs()) {
          this.startProcessingPolling();
        } else {
          this.stopProcessingPolling();
        }

        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Processing jobs API failed:', error);

        if (showLoader) {
          this.processingJobs = [];
        }

        this.stopProcessingPolling();
        this.cdr.detectChanges();
      },
    });
  }

  retryProcessing(): void {
    this.isRetrying = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.documentsService
      .retryProcessing(this.uuid)
      .pipe(
        finalize(() => {
          this.isRetrying = false;
        }),
      )
      .subscribe({
        next: (response) => {
          this.successMessage = response.detail;
          this.loadDocument();
          this.loadProcessingJobs();
          this.startProcessingPolling();
        },
        error: (error) => {
          this.errorMessage = error?.error?.detail || 'Unable to retry processing.';
        },
      });
  }

  deleteDocument(): void {
    const confirmed = window.confirm(
      'Delete this document? This action will remove it from the document list.',
    );

    if (!confirmed) {
      return;
    }

    this.isDeleting = true;
    this.errorMessage = '';

    this.documentsService
      .deleteDocument(this.uuid)
      .pipe(
        finalize(() => {
          this.isDeleting = false;
        }),
      )
      .subscribe({
        next: () => {
          this.router.navigate(['/documents']);
        },
        error: (error) => {
          this.errorMessage = error?.error?.detail || 'Unable to delete document.';
        },
      });
  }

  formatLabel(value: string): string {
    return value
      .replaceAll('_', ' ')
      .replaceAll('-', ' ')
      .replace(/\b\w/g, (character) => character.toUpperCase());
  }

  formatFileSize(size: number): string {
    if (!size) {
      return '0 B';
    }

    const units = ['B', 'KB', 'MB', 'GB'];
    const index = Math.floor(Math.log(size) / Math.log(1024));
    return `${(size / Math.pow(1024, index)).toFixed(2)} ${units[index]}`;
  }
}
