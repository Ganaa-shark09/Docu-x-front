import { NgFor, NgIf } from '@angular/common';
import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { finalize } from 'rxjs';

import { DepartmentOption } from '../../../core/models/document.model';
import { DocumentsService } from '../services/documents.service';

@Component({
  selector: 'app-document-upload-form',
  standalone: true,
  imports: [NgFor, NgIf, ReactiveFormsModule],
  template: `
    <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div class="mb-5">
        <h3 class="font-semibold text-slate-950">Upload Document</h3>
        <p class="text-sm text-slate-500">
          Upload PDF, image, text, CSV, or business document for AI processing.
        </p>
      </div>

      <form [formGroup]="form" (ngSubmit)="submit()" class="space-y-4">
        <div>
          <label class="mb-1 block text-sm font-medium text-slate-700">Title</label>
          <input
            type="text"
            formControlName="title"
            class="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-slate-900"
            placeholder="Invoice March 2026"
          />
        </div>

        <div>
          <label class="mb-1 block text-sm font-medium text-slate-700">Description</label>
          <textarea
            formControlName="description"
            rows="3"
            class="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-slate-900"
            placeholder="Optional document notes"
          ></textarea>
        </div>

        <div class="grid gap-4 md:grid-cols-3">
          <div>
            <label class="mb-1 block text-sm font-medium text-slate-700">Document Type</label>
            <select
              formControlName="document_type"
              class="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none focus:border-slate-900"
              style="color:#0f172a !important; background-color:#ffffff !important;"
            >
              <option style="color:#0f172a;background:#ffffff;" value="invoice">Invoice</option>
              <option style="color:#0f172a;background:#ffffff;" value="contract">Contract</option>
              <option style="color:#0f172a;background:#ffffff;" value="policy">Policy</option>
              <option style="color:#0f172a;background:#ffffff;" value="resume">Resume</option>
              <option style="color:#0f172a;background:#ffffff;" value="purchase_order">Purchase Order</option>
              <option style="color:#0f172a;background:#ffffff;" value="report">Report</option>
              <option style="color:#0f172a;background:#ffffff;" value="other">Other</option>
            </select>
          </div>

          <div>
            <label class="mb-1 block text-sm font-medium text-slate-700">Sensitivity</label>
            <select
              formControlName="sensitivity_label"
              class="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none focus:border-slate-900"
              style="color:#0f172a !important; background-color:#ffffff !important;"
            >
              <option style="color:#0f172a;background:#ffffff;" value="public">Public</option>
              <option style="color:#0f172a;background:#ffffff;" value="internal">Internal</option>
              <option style="color:#0f172a;background:#ffffff;" value="confidential">Confidential</option>
              <option style="color:#0f172a;background:#ffffff;" value="highly_confidential">Highly Confidential</option>
              <option style="color:#0f172a;background:#ffffff;" value="restricted">Restricted</option>
            </select>
          </div>

          <div>
            <label class="mb-1 block text-sm font-medium text-slate-700">Department</label>
            <select
              formControlName="department"
              class="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none focus:border-slate-900"
              style="color:#0f172a !important; background-color:#ffffff !important;"
            >
              <option style="color:#0f172a;background:#ffffff;" value="">No department</option>
              <option
                *ngFor="let department of departments"
                style="color:#0f172a;background:#ffffff;"
                [value]="department.uuid"
              >
                {{ department.name }}
              </option>
            </select>
          </div>
        </div>

        <div>
          <label class="mb-1 block text-sm font-medium text-slate-700">File</label>
          <input
            type="file"
            (change)="onFileSelected($event)"
            class="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 file:mr-4 file:rounded-lg file:border-0 file:bg-slate-950 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-white"
          />

          <p *ngIf="selectedFile" class="mt-2 text-xs text-slate-500">
            Selected: {{ selectedFile.name }} · {{ formatFileSize(selectedFile.size) }}
          </p>
        </div>

        <div
          *ngIf="errorMessage"
          class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
        >
          {{ errorMessage }}
        </div>

        <button
          type="submit"
          [disabled]="form.invalid || !selectedFile || isUploading"
          class="inline-flex min-w-[180px] items-center justify-center rounded-xl bg-slate-950 px-5 py-2.5 text-sm font-semibold text-white hover:bg-slate-800 disabled:cursor-not-allowed disabled:bg-slate-400 disabled:text-white"
          style="color:#ffffff !important;"
        >
          {{ isUploading ? 'Uploading...' : 'Upload Document' }}
        </button>
      </form>
    </div>
  `,
})
export class DocumentUploadFormComponent {
  private readonly fb = inject(FormBuilder);
  private readonly documentsService = inject(DocumentsService);

  @Input() departments: DepartmentOption[] = [];
  @Output() uploaded = new EventEmitter<void>();

  selectedFile: File | null = null;
  isUploading = false;
  errorMessage = '';

  readonly form = this.fb.nonNullable.group({
    title: ['', [Validators.required]],
    description: [''],
    document_type: ['invoice', [Validators.required]],
    sensitivity_label: ['internal', [Validators.required]],
    department: [''],
  });

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.selectedFile = input.files?.[0] ?? null;

    if (this.selectedFile && !this.form.controls.title.value.trim()) {
      const title = this.selectedFile.name.replace(/\.[^/.]+$/, '');
      this.form.controls.title.setValue(title);
    }
  }

  submit(): void {
    if (this.form.invalid || !this.selectedFile || this.isUploading) {
      this.form.markAllAsTouched();
      return;
    }

    this.isUploading = true;
    this.errorMessage = '';

    const values = this.form.getRawValue();

    this.documentsService
      .uploadDocument({
        title: values.title,
        description: values.description,
        document_type: values.document_type,
        sensitivity_label: values.sensitivity_label,
        department: values.department,
        file: this.selectedFile,
      })
      .pipe(
        finalize(() => {
          this.isUploading = false;
        }),
      )
      .subscribe({
        next: () => {
          this.form.reset({
            title: '',
            description: '',
            document_type: 'invoice',
            sensitivity_label: 'internal',
            department: '',
          });

          this.selectedFile = null;
          this.uploaded.emit();
        },
        error: (error) => {
          console.error('Document upload failed:', error);

          this.errorMessage =
            error?.error?.detail ||
            error?.error?.file?.[0] ||
            error?.error?.document_type?.[0] ||
            error?.error?.sensitivity_label?.[0] ||
            'Document upload failed. Please verify the backend and file type.';
        },
      });
  }

  formatFileSize(size: number): string {
    if (!size) {
      return '0 B';
    }

    const units = ['B', 'KB', 'MB', 'GB'];
    const index = Math.floor(Math.log(size) / Math.log(1024));

    return `${(size / Math.pow(1024, index)).toFixed(2)} ${units[index]}`;
  }
}
