import { DatePipe, NgClass, NgFor, NgIf } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';

import { DocumentProcessingJob } from '../../../core/models/document.model';

interface PipelineStage {
  key: string;
  label: string;
  description: string;
}

@Component({
  selector: 'app-document-processing-pipeline',
  standalone: true,
  imports: [DatePipe, NgClass, NgFor, NgIf],
  styles: [
    `
      .pipeline-flow-line {
        transform-origin: left center;
        background: linear-gradient(
          90deg,
          rgba(14, 165, 233, 0.35),
          rgba(45, 212, 191, 1),
          rgba(14, 165, 233, 0.35)
        );
        background-size: 220% 100%;
        animation:
          pipelineSegmentFill 0.38s ease-out both,
          pipelineWaterMove 1.1s linear infinite;
        animation-delay: var(--flow-delay), var(--flow-delay);
      }

      .pipeline-flow-dot {
        border-color: rgb(45 212 191);
        box-shadow: 0 0 0 4px rgba(45, 212, 191, 0.12);
        animation: pipelineDotPulse 0.35s ease-out both;
        animation-delay: var(--flow-delay);
      }

      @keyframes pipelineSegmentFill {
        0% {
          transform: scaleX(0);
          opacity: 0.25;
        }
        100% {
          transform: scaleX(1);
          opacity: 1;
        }
      }

      @keyframes pipelineWaterMove {
        0% {
          background-position: 220% 0;
        }
        100% {
          background-position: -220% 0;
        }
      }

      @keyframes pipelineDotPulse {
        0% {
          transform: scale(0.75);
          opacity: 0.4;
        }
        70% {
          transform: scale(1.18);
          opacity: 1;
        }
        100% {
          transform: scale(1);
          opacity: 1;
        }
      }
    `,
  ],
  template: `
    <div
      class="w-full max-w-full overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"
    >
      <div
        class="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 px-5 py-4"
      >
        <div class="min-w-0">
          <h3 class="font-semibold text-slate-950">Processing Pipeline</h3>
          <p class="text-sm text-slate-500">
            Hover a stage to see the processing path flow from OCR to that stage.
          </p>
        </div>

        <div class="flex shrink-0 items-center gap-3">
          <span
            class="rounded-full px-3 py-1 text-xs font-semibold"
            [ngClass]="pipelineStatusClass"
          >
            {{ pipelineStatusLabel }}
          </span>

          <button
            type="button"
            (click)="refresh.emit()"
            class="rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100"
          >
            Refresh
          </button>
        </div>
      </div>

      <div class="p-5">
        <div *ngIf="!jobs.length" class="rounded-xl bg-slate-50 p-5 text-sm text-slate-500">
          No processing jobs found yet.
        </div>

        <div *ngIf="jobs.length" class="space-y-5">
          <div
            #pipelineViewport
            class="relative h-[170px] w-full max-w-full cursor-grab select-none overflow-auto overscroll-contain rounded-2xl border border-slate-200 bg-slate-50 p-4 active:cursor-grabbing"
            (wheel)="onCanvasWheel($event)"
            (pointerdown)="startPan($event)"
            (pointermove)="pan($event)"
            (pointerup)="endPan($event)"
            (pointercancel)="endPan($event)"
            (mouseleave)="clearHover(); endPan($event)"
          >
            <div class="flex h-full min-w-0 items-center" [style.width.%]="workflowWidthPercent">
              <ng-container *ngFor="let stage of stages; let index = index; let last = last">
                <button
                  type="button"
                  data-pipeline-stage="true"
                  (pointerdown)="$event.stopPropagation()"
                  (click)="handleStageClick(stage.key)"
                  (mouseenter)="setHover(stage.key)"
                  class="relative h-[54px] min-w-0 flex-1 rounded-lg border bg-white px-2.5 py-2 text-left shadow-sm transition hover:shadow-md"
                  [ngClass]="cardClass(stage.key)"
                >
                  <!-- <div
                    class="pipeline-flow-card pointer-events-none absolute inset-y-0 left-0 transition-all duration-300"
                    [style.width.%]="isCardInFlow(stage.key) ? 100 : 0"
                  ></div> -->

                  <div class="relative z-10 flex items-start justify-between gap-2">
                    <div class="min-w-0">
                      <div class="truncate text-[11px] font-semibold leading-4 text-slate-900">
                        {{ stage.label }}
                      </div>
                      <div class="mt-0.5 truncate text-[10px] leading-3 text-slate-500">
                        {{ formatLabel(stageStatus(stage.key)) }}
                      </div>
                    </div>

                    <div
                      class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-bold"
                      [ngClass]="iconClass(stage.key)"
                    >
                      {{ icon(stage.key) }}
                    </div>
                  </div>

                  <div class="relative z-10 mt-2 flex items-center gap-1.5">
                    <div class="h-1 flex-1 rounded-full bg-slate-100">
                      <div
                        class="h-1 rounded-full"
                        [style.width.%]="progress(stage.key)"
                        [ngClass]="progressClass(stage.key)"
                      ></div>
                    </div>

                    <span class="shrink-0 text-[9px] text-slate-500">
                      {{ durationLabel(stage.key) }}
                    </span>
                  </div>
                </button>

                <div *ngIf="!last" class="flex w-[38px] shrink-0 items-center justify-center">
                  <span
                    class="h-2.5 w-2.5 rounded-full border-2 bg-white"
                    [ngClass]="connectorDotClass(stage.key, index)"
                    [style.--flow-delay]="flowDelay(index)"
                  ></span>

                  <span
                    class="h-[2px] flex-1 rounded-full"
                    [ngClass]="connectorLineClass(stage.key, stages[index + 1].key, index)"
                    [style.--flow-delay]="flowDelay(index)"
                  ></span>

                  <span
                    class="h-2.5 w-2.5 rounded-full border-2 bg-white"
                    [ngClass]="connectorDotClass(stages[index + 1].key, index + 1)"
                    [style.--flow-delay]="flowDelay(index + 1)"
                  ></span>
                </div>
              </ng-container>
            </div>

            <!-- <div class="sticky bottom-2 ml-auto mr-2 flex w-fit items-center gap-1.5">
              <button
                type="button"
                (click)="resetZoom()"
                class="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-100"
                title="Fit to container"
              >
                ⤢
              </button>

              <button
                type="button"
                (click)="zoomOut()"
                class="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 bg-white text-base font-semibold text-slate-700 shadow-sm hover:bg-slate-100"
                title="Zoom out"
              >
                −
              </button>

              <button
                type="button"
                (click)="zoomIn()"
                class="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 bg-white text-base font-semibold text-slate-700 shadow-sm hover:bg-slate-100"
                title="Zoom in"
              >
                +
              </button>
            </div> -->
          </div>

          <div class="rounded-2xl border border-slate-200 bg-slate-50 p-5">
            <div class="mb-4 flex flex-wrap items-start justify-between gap-4">
              <div>
                <h4 class="text-lg font-semibold text-slate-950">
                  {{ selectedStage.label }}
                </h4>
                <p class="text-sm text-slate-500">
                  {{ selectedStage.description }}
                </p>
              </div>

              <span
                class="rounded-full px-3 py-1 text-xs font-semibold"
                [ngClass]="statusBadgeClass(stageStatus(selectedStage.key))"
              >
                {{ formatLabel(stageStatus(selectedStage.key)) }}
              </span>
            </div>

            <ng-container *ngIf="selectedJob; else notStartedState">
              <div class="grid gap-4 md:grid-cols-3">
                <div class="rounded-xl bg-white p-4">
                  <p class="text-xs font-semibold uppercase text-slate-400">Started</p>
                  <p class="mt-1 text-sm text-slate-700">
                    {{ selectedJob.started_at ? (selectedJob.started_at | date: 'medium') : '-' }}
                  </p>
                </div>

                <div class="rounded-xl bg-white p-4">
                  <p class="text-xs font-semibold uppercase text-slate-400">Completed</p>
                  <p class="mt-1 text-sm text-slate-700">
                    {{
                      selectedJob.completed_at ? (selectedJob.completed_at | date: 'medium') : '-'
                    }}
                  </p>
                </div>

                <div class="rounded-xl bg-white p-4">
                  <p class="text-xs font-semibold uppercase text-slate-400">Updated</p>
                  <p class="mt-1 text-sm text-slate-700">
                    {{ selectedJob.updated_at | date: 'medium' }}
                  </p>
                </div>
              </div>

              <div class="mt-4 rounded-xl bg-white p-4">
                <p class="text-xs font-semibold uppercase text-slate-400">Job Type</p>
                <p class="mt-1 text-sm font-medium text-slate-900">
                  {{ selectedJob.job_type }}
                </p>
              </div>

              <div
                *ngIf="selectedJob.error_message"
                class="mt-4 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700"
              >
                <p class="font-semibold">Error</p>
                <p class="mt-1 whitespace-pre-wrap">{{ selectedJob.error_message }}</p>
              </div>

              <div
                *ngIf="!selectedJob.error_message"
                class="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700"
              >
                No error recorded for this stage.
              </div>
            </ng-container>

            <ng-template #notStartedState>
              <div class="rounded-xl border border-slate-200 bg-white p-4 text-sm text-slate-500">
                This stage has not started yet.
              </div>
            </ng-template>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class DocumentProcessingPipelineComponent {
  @Input() jobs: DocumentProcessingJob[] = [];
  @Output() refresh = new EventEmitter<void>();

  @ViewChild('pipelineCanvas')
  pipelineCanvas?: ElementRef<HTMLDivElement>;

  selectedStageKey = 'ocr';
  hoveredStageKey = '';
  zoomLevel = 1;
  panX = 0;
  panY = 0;

  @ViewChild('pipelineViewport')
  pipelineViewport?: ElementRef<HTMLDivElement>;

  isDragging = false;
  hasDragged = false;
  suppressNextClick = false;

  private dragStartX = 0;
  private dragStartY = 0;
  private dragStartPanX = 0;
  private dragStartPanY = 0;
  private dragStartScrollLeft = 0;
  private dragStartScrollTop = 0;

  readonly minZoom = 1;
  readonly maxZoom = 1.8;
  readonly zoomStep = 0.1;

  readonly stages: PipelineStage[] = [
    {
      key: 'ocr',
      label: 'OCR',
      description: 'Extracts readable text from PDF, image, text, or CSV documents.',
    },
    {
      key: 'classification',
      label: 'Classification',
      description: 'Detects document category such as invoice, contract, policy, or report.',
    },
    {
      key: 'firewall_scan',
      label: 'Firewall Scan',
      description: 'Scans content for sensitive data and decides AI usage policy.',
    },
    {
      key: 'chunking',
      label: 'Chunking',
      description: 'Splits extracted text into semantic chunks for search and RAG.',
    },
    {
      key: 'embedding',
      label: 'Embedding',
      description: 'Generates vector embeddings for each document chunk.',
    },
    {
      key: 'indexing',
      label: 'Indexing',
      description: 'Stores document chunks and embeddings for vector search and AI chat.',
    },
  ];

  get workflowWidthPercent(): number {
    return this.zoomLevel * 100;
  }
  startPan(event: PointerEvent): void {
    if (event.button !== 0) {
      return;
    }

    const target = event.target as HTMLElement | null;

    if (target?.closest('[data-pipeline-stage="true"]')) {
      return;
    }

    this.isDragging = true;
    this.hasDragged = false;

    this.dragStartX = event.clientX;
    this.dragStartY = event.clientY;
    this.dragStartPanX = this.panX;
    this.dragStartPanY = this.panY;

    this.pipelineCanvas?.nativeElement.setPointerCapture(event.pointerId);
  }

  pan(event: PointerEvent): void {
    if (!this.isDragging) {
      return;
    }

    const viewport = this.pipelineViewport?.nativeElement;

    if (!viewport) {
      return;
    }

    const deltaX = event.clientX - this.dragStartX;
    const deltaY = event.clientY - this.dragStartY;

    if (Math.abs(deltaX) > 4 || Math.abs(deltaY) > 4) {
      this.hasDragged = true;
    }

    viewport.scrollLeft = this.dragStartScrollLeft - deltaX;
    viewport.scrollTop = this.dragStartScrollTop - deltaY;
  }

  endPan(event?: PointerEvent | MouseEvent): void {
    if (!this.isDragging) {
      return;
    }

    const viewport = this.pipelineViewport?.nativeElement;

    if (viewport && event) {
      try {
        if (event && 'pointerId' in event) {
          this.pipelineCanvas?.nativeElement.releasePointerCapture(event.pointerId);
        }
      } catch {
        // Ignore pointer capture release errors.
      }
    }

    this.isDragging = false;

    if (this.hasDragged) {
      this.suppressNextClick = true;

      setTimeout(() => {
        this.suppressNextClick = false;
        this.hasDragged = false;
      }, 0);
    }
  }

  handleStageClick(stageKey: string): void {
    this.selectedStageKey = stageKey;
  }

  get workflowTransform(): string {
    return `translate(${this.panX}px, ${this.panY}px) translateY(-50%) scale(${this.zoomLevel})`;
  }

  get selectedStage(): PipelineStage {
    return this.stages.find((stage) => stage.key === this.selectedStageKey) || this.stages[0];
  }

  get selectedJob(): DocumentProcessingJob | null {
    return this.latestJobByType(this.selectedStage.key);
  }

  get flowTargetIndex(): number {
    const targetKey = this.hoveredStageKey || this.selectedStageKey;
    const index = this.stages.findIndex((stage) => stage.key === targetKey);
    return index >= 0 ? index : 0;
  }

  get pipelineStatusLabel(): string {
    if (this.hasFailedJob) return 'Failed';
    if (this.hasRunningJob) return 'Running';
    if (this.allSuccess) return 'Completed';
    return 'Pending';
  }

  get pipelineStatusClass(): string {
    if (this.hasFailedJob) return 'bg-red-100 text-red-700';
    if (this.hasRunningJob) return 'bg-amber-100 text-amber-700';
    if (this.allSuccess) return 'bg-emerald-100 text-emerald-700';
    return 'bg-slate-100 text-slate-700';
  }

  get hasFailedJob(): boolean {
    return this.jobs.some((job) => job.status === 'failed');
  }

  get hasRunningJob(): boolean {
    return this.jobs.some((job) => ['pending', 'running'].includes(job.status));
  }

  get allSuccess(): boolean {
    return (
      this.jobs.length > 0 &&
      this.stages.every((stage) => this.stageStatus(stage.key) === 'success')
    );
  }

  onCanvasWheel(event: WheelEvent): void {
    event.preventDefault();

    if (event.deltaY < 0) {
      this.zoomIn();
    } else {
      this.zoomOut();
    }
  }

  zoomIn(): void {
    this.zoomLevel = Math.min(this.maxZoom, Number((this.zoomLevel + this.zoomStep).toFixed(2)));
  }

  zoomOut(): void {
    this.zoomLevel = Math.max(this.minZoom, Number((this.zoomLevel - this.zoomStep).toFixed(2)));
  }

  resetZoom(): void {
    this.zoomLevel = 1;
  }

  setHover(stageKey: string): void {
    this.hoveredStageKey = stageKey;
  }

  clearHover(): void {
    this.hoveredStageKey = '';
  }

  selectStage(stageKey: string): void {
    this.selectedStageKey = stageKey;
  }

  flowDelay(index: number): string {
    return `${index * 160}ms`;
  }

  // isCardInFlow(stageKey: string): boolean {
  //   const index = this.stages.findIndex((stage) => stage.key === stageKey);
  //   return index >= 0 && index <= this.flowTargetIndex;
  // }

  isConnectorInFlow(index: number): boolean {
    return index < this.flowTargetIndex;
  }

  latestJobByType(jobType: string): DocumentProcessingJob | null {
    const matchingJobs = this.jobs
      .filter((job) => job.job_type === jobType)
      .sort((a, b) => {
        const left = new Date(a.updated_at || a.created_at).getTime();
        const right = new Date(b.updated_at || b.created_at).getTime();
        return right - left;
      });

    return matchingJobs[0] || null;
  }

  stageStatus(stageKey: string): string {
    return this.latestJobByType(stageKey)?.status || 'not_started';
  }

  icon(stageKey: string): string {
    switch (this.stageStatus(stageKey)) {
      case 'success':
        return '✓';
      case 'running':
        return '●';
      case 'pending':
        return '○';
      case 'failed':
        return '!';
      default:
        return '·';
    }
  }

  iconClass(stageKey: string): string {
    switch (this.stageStatus(stageKey)) {
      case 'success':
        return 'bg-emerald-500 text-white';
      case 'running':
        return 'animate-pulse bg-amber-500 text-white';
      case 'pending':
        return 'bg-amber-100 text-amber-700';
      case 'failed':
        return 'bg-red-500 text-white';
      default:
        return 'bg-slate-100 text-slate-400';
    }
  }

  cardClass(stageKey: string): string {
    const status = this.stageStatus(stageKey);
    const selected = this.selectedStageKey === stageKey;

    if (selected) {
      return 'border-sky-300 bg-sky-50 ring-2 ring-sky-200';
    }

    switch (status) {
      case 'success':
        return 'border-emerald-200';
      case 'running':
        return 'border-amber-300';
      case 'pending':
        return 'border-amber-200';
      case 'failed':
        return 'border-red-300';
      default:
        return 'border-slate-200';
    }
  }

  progress(stageKey: string): number {
    switch (this.stageStatus(stageKey)) {
      case 'success':
        return 100;
      case 'running':
        return 65;
      case 'pending':
        return 20;
      case 'failed':
        return 100;
      default:
        return 0;
    }
  }

  progressClass(stageKey: string): string {
    switch (this.stageStatus(stageKey)) {
      case 'success':
        return 'bg-emerald-500';
      case 'running':
        return 'bg-amber-500';
      case 'pending':
        return 'bg-amber-300';
      case 'failed':
        return 'bg-red-500';
      default:
        return 'bg-slate-200';
    }
  }

  connectorDotClass(stageKey: string, index: number): string {
    if (index <= this.flowTargetIndex) {
      return 'pipeline-flow-dot border-cyan-400';
    }

    switch (this.stageStatus(stageKey)) {
      case 'success':
        return 'border-emerald-500';
      case 'running':
      case 'pending':
        return 'border-amber-500';
      case 'failed':
        return 'border-red-500';
      default:
        return 'border-slate-300';
    }
  }

  connectorLineClass(leftStageKey: string, rightStageKey: string, index: number): string {
    if (this.isConnectorInFlow(index)) {
      return 'pipeline-flow-line';
    }

    const leftStatus = this.stageStatus(leftStageKey);
    const rightStatus = this.stageStatus(rightStageKey);

    if (leftStatus === 'failed' || rightStatus === 'failed') return 'bg-red-400';
    if (leftStatus === 'success' && rightStatus === 'success') return 'bg-emerald-400';

    if (
      ['success', 'running', 'pending'].includes(leftStatus) &&
      ['running', 'pending', 'success'].includes(rightStatus)
    ) {
      return 'bg-amber-400';
    }

    return 'bg-slate-300';
  }

  statusBadgeClass(status: string): string {
    switch (status) {
      case 'success':
        return 'bg-emerald-100 text-emerald-700';
      case 'running':
      case 'pending':
        return 'bg-amber-100 text-amber-700';
      case 'failed':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-slate-100 text-slate-700';
    }
  }

  durationLabel(stageKey: string): string {
    const job = this.latestJobByType(stageKey);

    if (!job?.started_at) return '';

    const started = new Date(job.started_at).getTime();
    const finished = job.completed_at
      ? new Date(job.completed_at).getTime()
      : new Date(job.updated_at || job.started_at).getTime();

    const diffSeconds = Math.max(0, Math.round((finished - started) / 1000));

    if (diffSeconds < 60) return `${diffSeconds}s`;

    const minutes = Math.floor(diffSeconds / 60);
    const seconds = diffSeconds % 60;

    if (minutes < 60) return `${minutes}m ${seconds}s`;

    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;

    return `${hours}h ${remainingMinutes}m`;
  }

  formatLabel(value: string): string {
    return value
      .replaceAll('_', ' ')
      .replaceAll('-', ' ')
      .replace(/\b\w/g, (character) => character.toUpperCase());
  }
}
